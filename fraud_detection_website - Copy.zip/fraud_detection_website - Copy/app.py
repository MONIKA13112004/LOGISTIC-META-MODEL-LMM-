from flask import Flask, request, jsonify
from flask_cors import CORS  # Import CORS
import numpy as np
import joblib

app = Flask(__name__)
CORS(app)  # Enable CORS

# Load the trained model and scaler
model = joblib.load("model.pkl")
scaler = joblib.load("scaler.pkl")

FEATURE_COLUMNS = ['Time', 'V1', 'V2', 'V3', 'V4', 'V5', 'V6', 'V7', 'V8', 'V9', 
                   'V10', 'V11', 'V12', 'V13', 'V14', 'V15', 'V16', 'V17', 'V18', 'V19', 
                   'V20', 'V21', 'V22', 'V23', 'V24', 'V25', 'V26', 'V27', 'V28', 'Amount']

@app.route("/predict", methods=["POST"])
def predict():
    try:
        data = request.form["features"]
        input_features = np.array([float(x) for x in data.split(",")]).reshape(1, -1)
        input_scaled = scaler.transform(input_features)

        prediction = model.predict(input_scaled)[0]
        result = "Fraudulent Transaction" if prediction == 1 else "Not Fraudulent"

        return jsonify({"prediction": result})

    except Exception as e:
        return jsonify({"error": str(e)})

if __name__ == "__main__":
    app.run(debug=True)
